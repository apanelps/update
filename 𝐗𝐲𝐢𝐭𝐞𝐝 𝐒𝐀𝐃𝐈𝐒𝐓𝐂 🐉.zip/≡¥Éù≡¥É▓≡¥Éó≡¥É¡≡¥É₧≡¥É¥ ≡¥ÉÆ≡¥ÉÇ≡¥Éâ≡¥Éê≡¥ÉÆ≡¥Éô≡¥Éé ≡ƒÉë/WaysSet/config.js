export default {
    API_TOKEN: 'TOKEN_BOT_TELEGRAM_ANDA',
    OWNER_USERNAME: '@Yazira01',
    BOT_NAME: 'YaziraXmodz',
    IMG_URL: 'https://telegra.ph/file/07f46401050e608041c2c.jpg',
    COOLDOWN_TIME: 5 * 60 * 1000 // Jeda 5 menit
};
